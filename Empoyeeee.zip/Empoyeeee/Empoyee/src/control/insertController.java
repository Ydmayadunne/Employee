
package control;

import javax.swing.JOptionPane;

public class insertController {
    
    public static void addintern(String id , String name ,String email ,  String address , String contact , String gender , String status , String department ){
        
        if(id.equals("") || name.equals("") || email.equals("") || address.equals("")|| contact.equals("") || gender.equals("") || status.equals("") || department.equals("")){
            JOptionPane.showMessageDialog(null, "adding failed");
        }else{
            JOptionPane.showMessageDialog(null, "added");
            new Model.DBinsert().addIntern(id , name , email , address , contact , gender , status , department );
        }
    }
    
    public static void addoperative(String id , String name ,String email ,  String address , String contact , String gender , String status , String department ){
        
        if(id.equals("") || name.equals("") || email.equals("") || address.equals("")|| contact.equals("") || gender.equals("") || status.equals("") || department.equals("")){
            JOptionPane.showMessageDialog(null, "adding failed");
        }else{
            JOptionPane.showMessageDialog(null, "added ");
            new Model.DBinsert().addOperative(id , name , email , address , contact , gender , status , department );
        }
    }

    public static void addstudent(String id, String name, String email, String address, String contact, String gender, String status, String department){
        
        if(id.equals("") || name.equals("") || email.equals("") || address.equals("")|| contact.equals("") || gender.equals("") || status.equals("") || department.equals("")){
            JOptionPane.showMessageDialog(null, "adding failed");
        }else{
            JOptionPane.showMessageDialog(null, "added ");
            new Model.DBinsert().addStudent(id , name , email , address , contact , gender , status , department);
        }
    }
}
