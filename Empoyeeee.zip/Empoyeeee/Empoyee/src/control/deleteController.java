
package control;

import javax.swing.JOptionPane;

public class deleteController {
    
    public static void deleteintern(String id ){
        
        if(id.equals("") ){
            JOptionPane.showMessageDialog(null, "Deleted failed");
        }else{
            JOptionPane.showMessageDialog(null, "Deleted ");
            new Model.DBdelete(). deleteIntern(id );
        }
    }
    
    public static void deleteoperative(String id){
        
        if(id.equals("") ){
            JOptionPane.showMessageDialog(null, "Deleted failed");
        }else{
            JOptionPane.showMessageDialog(null, "Deleted ");
            new Model.DBdelete(). deleteOperative(id);
        }
    }
    
     public static void deletestudent(String id){
        
        if(id.equals("") ){
            JOptionPane.showMessageDialog(null, "Deleted failed");
        }else{
            JOptionPane.showMessageDialog(null, "Deleted ");
            new Model.DBdelete(). deleteStudent(id);
        }
     }
    
}
