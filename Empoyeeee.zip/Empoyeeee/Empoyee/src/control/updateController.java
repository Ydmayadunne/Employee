
package control;

import javax.swing.JOptionPane;

public class updateController {
    
    public static void updateIntern(String id , String name ,String email ,  String address , String contact , String gender , String status , String department ){
        
        if (id.equals("") || name.equals("") || email.equals("") || address.equals("")|| contact.equals("") || gender.equals("") || status.equals("") || department.equals("")){
            JOptionPane.showMessageDialog(null, "update failed");
        }else{
            JOptionPane.showMessageDialog(null, "updated ");
            new Model.DBupdate().updateIntern(id , name , email , address , contact , gender , status , department );
        }
    }

    public static void updateoperative(String id , String name ,String email ,  String address , String contact , String gender , String status , String department ){
        
        if (id.equals("") || name.equals("") || email.equals("") || address.equals("")|| contact.equals("") || gender.equals("") || status.equals("") || department.equals("")){
            JOptionPane.showMessageDialog(null, "update failed");
        }else{
            JOptionPane.showMessageDialog(null, "updated ");
            new Model.DBupdate().updateOperative(id , name , email , address , contact , gender , status , department);
        }
    }
    
    public static void updateStudent(String id , String name ,String email ,  String address , String contact , String gender , String status , String department ){
        
        if(id.equals("") || name.equals("") || email.equals("") || address.equals("")|| contact.equals("") || gender.equals("") || status.equals("") || department.equals("")){
            JOptionPane.showMessageDialog(null, "update failed");
        }else{
            JOptionPane.showMessageDialog(null, "updated ");
            new Model.DBupdate().updateStudent(id , name , email , address , contact , gender , status , department);
        }
    }
}
