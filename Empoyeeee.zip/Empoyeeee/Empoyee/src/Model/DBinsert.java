
package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;


public class DBinsert {
    
    public boolean addIntern (String id , String name ,String email ,  String address , String contact , String gender , String status , String department ){
    boolean isAdded = false;

    try {
        Connection conn = DBConnection.getconnection();
        String sql = "insert into intern values (?,?,?,?,?,?,?,?)";
        PreparedStatement pst = conn.prepareStatement(sql);

        pst.setString(1, id);
        pst.setString(2, name);
        pst.setString(3, email);
        pst.setString(4, address);
        pst.setString(5, contact);
        pst.setString(6, gender);
        pst.setString(7, status);
        pst.setString(8, department);
        
        int rowCount = pst.executeUpdate();
        if(rowCount> 0){
            isAdded = true;
        }else {
            isAdded = false;
        }
        
    } catch (Exception e) {
        e.printStackTrace();
    }
    return isAdded;
}
        
    public boolean addOperative (String id , String name ,String email ,  String address , String contact , String gender , String status , String department ){
    boolean isAdded = false;
    
    
    try {
         Connection conn = DBConnection.getconnection();
        String sql = "insert into operative values (?,?,?,?,?,?,?,?)";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, id);
        pst.setString(2, name);
        pst.setString(3, email);
        pst.setString(4, address);
        pst.setString(5, contact);
        pst.setString(6, gender);
        pst.setString(7, status);
        pst.setString(8, department); 
        
        int rowCount = pst.executeUpdate();
        if(rowCount> 0){
            isAdded = true;
        }else {
            isAdded = false;
        }
        
    } catch (Exception e) {
        e.printStackTrace();
    }
    return isAdded;
}
    
    public boolean addStudent (String id , String name ,String email ,  String address , String contact , String gender , String status , String department ){
    boolean isadded = false;    
     
            try {
         Connection conn = DBConnection.getconnection();
        String sql = "insert into student (id , name , email , address , contact , gender , status , department ) values (?,?,?,?,?,?,?,?)";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, id);
        pst.setString(2, name);
        pst.setString(3, email);
        pst.setString(4, address);
        pst.setString(5, contact);
        pst.setString(6, gender);
        pst.setString(7, status);
        pst.setString(8, department); 
        
      int rowCount = pst.executeUpdate();
       if(rowCount >0 ){
         isadded = true;
           } else {
         isadded = false;
}

      } catch (Exception e) {
      }
        return isadded;    
  } 
  
}
