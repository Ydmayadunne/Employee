
package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;

public class DBupdate {
    
    public boolean updateIntern(String id , String name ,String email ,  String address , String contact , String gender , String status , String department ){
    boolean isUpdated = false;
        
    
  
    try {
        Connection conn = DBConnection.getconnection();
        String sql = " update intern set name = ?, email = ?, address = ? , contact = ? , gender = ? , status = ?, department = ? where Id = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        
        pst.setString(1,name);
        pst.setString(2,email);
        pst.setString(3,address);
        pst.setString(4,contact);
        pst.setString(5,gender);
        pst.setString(6, status);
        pst.setString(7, department);
        pst.setString(8, id);
        
        int rowCount = pst.executeUpdate();
        if(rowCount> 0){
            isUpdated = true;
        }else {
            isUpdated = false ;
        }pst.close();
            conn.close();
        
    } catch (Exception e) {
        e.printStackTrace();
    }
    return isUpdated;
} 
    
    public boolean updateStudent(String id , String name ,String email ,  String address , String contact , String gender , String status , String department ){
    boolean isUpdated = false;
    
    try {
         Connection conn = DBConnection.getconnection();
        String sql = "UPDATE student SET name = ?, email = ?, address = ? , contact = ? , gender = ? , status = ?, department = ? where Id = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
         pst.setString(1,name);
        pst.setString(2,email);
        pst.setString(3,address);
        pst.setString(4,contact);
        pst.setString(5,gender);
        pst.setString(6, status);
        pst.setString(7, department);
        pst.setString(8, id);
        
        
        int rowCount = pst.executeUpdate();
        if(rowCount> 0){
            isUpdated = true;
        }else {
            isUpdated = false ;
        }
        pst.close();
            conn.close();
    } catch (Exception e) {
        e.printStackTrace();
    }
    return isUpdated;
}
    
    public boolean updateOperative(String id , String name ,String email ,  String address , String contact , String gender , String status , String department ){
    boolean isUpdated = false;
    try {
        Connection conn = DBConnection.getconnection();
        String sql = " UPDATE operative SET name = ?, email = ?, address = ? , contact = ? , gender = ? , status = ?, department = ? where Id = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1,name);
        pst.setString(2,email);
        pst.setString(3,address);
        pst.setString(4,contact);
        pst.setString(5,gender);
        pst.setString(6, status);
        pst.setString(7, department);
        pst.setString(8, id);
        
        int rowCount = pst.executeUpdate();
        if(rowCount> 0){
            isUpdated = true;
        }else {
            isUpdated = false ;
        }
        pst.close();
            conn.close();
        
    } catch (Exception e) {
        e.printStackTrace();
    }
    return isUpdated;
}

}
