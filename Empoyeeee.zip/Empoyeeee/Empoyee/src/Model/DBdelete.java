
package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class DBdelete {
    public boolean deleteIntern(String id){
        boolean isDeleted = false;

        try {
            Connection conn = DBConnection.getconnection();
           String sql = "delete from intern where Id = ?";
           PreparedStatement pst = conn.prepareStatement(sql);
           pst.setString(1,id);
           
           int rowCount = pst.executeUpdate();
           if(rowCount >0 ){
               isDeleted = true;
           }else {
               isDeleted = false;
           }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isDeleted;
    }
    
    public boolean deleteStudent(String id){
        boolean isDeleted = false;
        
        
        try {
           Connection conn = DBConnection.getconnection();
           String sql = "delete from student where id = ?";
           PreparedStatement pst = conn.prepareStatement(sql);
           pst.setString(1,id);
           
           int rowCount = pst.executeUpdate();
           if(rowCount >0 ){
               isDeleted = true;
           }else {
               isDeleted = false;
           }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isDeleted;
    }
    
     
    public boolean deleteOperative(String id){
        boolean isDeleted = false;
        
        
        try {
            Connection conn = DBConnection.getconnection();
           String sql = "delete from operative where id = ?";
           PreparedStatement pst = conn.prepareStatement(sql);
           pst.setString(1,id);
           
           int rowCount = pst.executeUpdate();
           if(rowCount >0 ){
               isDeleted = true;
           }else {
               isDeleted = false;
           }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isDeleted;
    }
    
    
}
