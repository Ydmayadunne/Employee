
package Model;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class DBtable {
    
    public static void setInternsToTable(DefaultTableModel model , JTable Table){
    try {
        Connection conn = DBConnection.getconnection();
        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery(" select * from intern");
        
        while(rs.next()){
            int id = rs. getInt ("id");
            String name = rs. getString ("name");
            String email = rs. getString ("email");
            String address = rs. getString ("address");
            int contact  = rs. getInt ("contact");
            String gender = rs. getString ("gender");
            String status = rs. getString ("status");
            String department = rs. getString ("department");
            
            Object[] obj = {id, name ,email ,address , contact , gender, status,department};
            model =(DefaultTableModel) Table.getModel();
            model.addRow(obj);
        }
    
    } catch (Exception e) {
        e.printStackTrace();
    }
    
} 
    
    public static void setOperativesToTable(DefaultTableModel model , JTable Table){
    try {
        Connection conn = DBConnection.getconnection();
        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery(" select * from operative");
        
        while(rs.next()){
            int id = rs. getInt ("id");
            String name = rs. getString ("name");
            String email = rs. getString ("email");
            String address = rs. getString ("address");
            int contact  = rs. getInt ("contact");
            String gender = rs. getString ("gender");
            String status = rs. getString ("status");
            String department = rs. getString ("department");
            
            Object[] obj = {id, name ,email ,address , contact , gender, status,department};
            model =(DefaultTableModel) Table.getModel();
            model.addRow(obj);
        }
    
    } catch (Exception e) {
        e.printStackTrace();
    }
    
} 
    public static void setStudentToTable(DefaultTableModel model , JTable Table){
    try {
        Connection conn = DBConnection.getconnection();
        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery(" select * from student");
        
        while(rs.next()){
            int id = rs. getInt ("id");
            String name = rs. getString ("name");
            String email = rs. getString ("email");
            String address = rs. getString ("address");
            int contact  = rs. getInt ("contact");
            String gender = rs. getString ("gender");
            String status = rs. getString ("status");
            String department = rs. getString ("department");
            
            Object[] obj = {id, name ,email ,address , contact , gender, status,department};
            model =(DefaultTableModel) Table.getModel();
            model.addRow(obj);
        }
    
    } catch (Exception e) {
        e.printStackTrace();
    }
    
}  

}
